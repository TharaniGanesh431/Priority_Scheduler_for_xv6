#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int argc, char *argv[] )
{
	int priority, pid;

	if(argc < 3 ){						//Invalid Entry
		printf(1,"Invalid Entry of Inputs!!!\n");
		exit();
	}

	pid = atoi( argv[1] );					//Input of exiting Pid
	
	priority = atoi( argv[2] );				//Input of corresponding priority

	if( priority < 0 || priority > 20 ) {			//Invalid Entry of priority Entry
		printf(1, "Invalid priority (0-20)!\n" );
		exit();
	}

	printf(1," pid=%d, pr=%d\n", pid,priority );

	chpr( pid, priority );					//Function call to change priority

	exit();
}
