#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[]) {
  int pid;
  int k, n;
  int x, z;

  if (argc != 2) {										
    printf(2, "usage: %s n\n", argv[0]);            // default value
  }

  n = atoi(argv[1]);								// Input from User - No. Of Process

  for ( k = 0; k < n; k++ ) {
    pid = fork ();

    if ( pid < 0 ) {                                // Failed in creating a process

      printf(1, "%d failed in fork!\n", getpid());
      exit();
    } 
    else if (pid == 0) {                            // child process
      
      printf(1, "Child %d created\n",getpid());

      for ( z = 0; z < 10000.0; z += 0.01 )         // Making the child process as CPU Bound
         x =  x + 1.23 * 45.67;  
      exit();
    }
  }

  for (k = 0; k < n; k++) {							// parent process
    wait();
  }

  exit();
}
